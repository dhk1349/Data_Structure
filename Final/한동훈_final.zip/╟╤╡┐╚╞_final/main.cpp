/**
*	@mainpage
*	@date	2019/03/26
*	@author	 �ѵ���
*/

#include "Application.h"
#include"AllType.h"
/**
*	program main function for data structures course.
*/
int main()
{
	Application app;	// Program application
	app.Run2();			// run program

	return 0;
}